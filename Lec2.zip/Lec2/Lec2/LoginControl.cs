﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec2
{
    class LoginControl
    {

        public void AddLogin(string fn,string pass)
        {
            LoginEntity le;
            le = new LoginEntity(fn, pass);
        }
    }
}
