﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec2
{
    class LoginEntity
    {

        public string Firstname;
        public string Password;

        public LoginEntity(string fn,string pass)
        {
            this.Firstname = fn;
            this.Password = pass;
        }
    }
}
